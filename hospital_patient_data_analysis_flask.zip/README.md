# Hospital Patient Data Analysis System
2nd-Year B.Tech CSE (AI/ML) Academic Project

## Quick Start
1. Install dependencies:
   pip install -r requirements.txt

2. Run Flask server:
   python app.py

3. Open in browser:
   http://127.0.0.1:5000
